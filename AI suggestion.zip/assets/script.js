document.getElementById('aiForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const category = document.getElementById('category').value;
  const goal = document.getElementById('goal').value;

  document.getElementById('loading').style.display = 'block';
  document.getElementById('result').innerHTML = '';

  fetch('api/suggest.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ category, goal })
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById('loading').style.display = 'none';

    // Only show pure text
    if (data.template || data.layout || data.content) {
      let html = "";

      if (data.template) {
        html += `<p><strong>Template:</strong> ${data.template}</p>`;
      }
      if (data.layout) {
        html += `<p><strong>Layout:</strong> ${data.layout}</p>`;
      }
      if (data.content) {
        html += `<p><strong>Content:</strong><br>${data.content}</p>`;
      }

      document.getElementById('result').innerHTML = html;
    } else if (data.response) {
      // If the AI returns just a text string
      document.getElementById('result').textContent = data.response;
    } else if (data.error) {
      document.getElementById('result').textContent = "Error: " + data.error;
    } else {
      document.getElementById('result').textContent = "No result found.";
    }
  })
  .catch(err => {
    document.getElementById('loading').style.display = 'none';
    document.getElementById('result').textContent = "Error: " + err.message;
  });
});
