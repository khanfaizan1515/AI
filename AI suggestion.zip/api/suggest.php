<?php
require_once __DIR__ . '/../vendor/autoload.php';

use GuzzleHttp\Client;
use Dotenv\Dotenv;

// Load .env
$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

header('Content-Type: application/json');

$input = json_decode(file_get_contents("php://input"), true);

if (!$input || !isset($input['category']) || !isset($input['goal'])) {
    echo json_encode(['error' => 'Invalid input']);
    exit;
}

$category = $input['category'];
$goal = $input['goal'];


$prompt = "You're an AI assistant for a website builder. Based on the following user input, suggest:
1. A website template name
2. A layout style
3. A short homepage content message

Category: $category
Goal: $goal

Respond in JSON with keys: template, layout, content.";

try {
    $client = new Client();

    $response = $client->post('https://openrouter.ai/api/v1/chat/completions', [
        'headers' => [
            'Authorization' => 'Bearer ' . $_ENV['OPENROUTER_API_KEY'],
            'Content-Type' => 'application/json',
            'HTTP-Referer' => 'http://localhost/AI/', // required by OpenRouter
            'X-Title' => 'AI Suggestion API'
        ],
        'json' => [
            'model' => 'gryphe/mythomax-l2-13b', // free model, very capable
            'messages' => [
                ['role' => 'system', 'content' => 'You are a helpful assistant.'],
                ['role' => 'user', 'content' => $prompt]
            ],
            'temperature' => 0.7,
            'max_tokens' => 300
        ]
    ]);

    $body = json_decode($response->getBody(), true);
    $aiResponse = $body['choices'][0]['message']['content'];

    $json = json_decode($aiResponse, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        echo json_encode($json);
    } else {
        echo json_encode(['response' => $aiResponse]);
    }

} catch (Exception $e) {
    echo json_encode(['error' => 'OpenRouter API failed', 'details' => $e->getMessage()]);
}

